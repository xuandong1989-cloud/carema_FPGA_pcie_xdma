#!/bin/bash
cd  XDMA/linux-kernel/xdma
make ARCH=arm64 CROSS_COMPILE=aarch64-none-linux-gnu-